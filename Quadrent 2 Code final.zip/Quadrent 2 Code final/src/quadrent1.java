
public class quadrent1 {

}

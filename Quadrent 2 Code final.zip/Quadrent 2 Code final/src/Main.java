
import rxtxrobot.*;
public class Main {
	private static int test=0;
	//our robots current heading or angle
	private static int heading=85;
	
	//beacon 1 2 3 are the beacons that will be scaned by the robot;
	private static beacon beacon1;
	private static beacon beacon2;
	private static beacon beacon3;
	private static int[] distances=new int[3];
	private static boolean b1d=false;
	private static boolean b2d=false;
	public static Servomotors IRServo;
	//x and y are robots x and y corrdinats 
	
	private static double x;
	private static double y;
	//desx and desy our are target x and y
	private static double desx;
	private static double desy;
	public static boolean done=false;
	public static RXTXRobot Robot = new ArduinoNano();
	//general direction of desired heading up being 90/ left being 180/ down being 270, right being 0
	private static int direction=90;
	//private static int heading=85;
	//private static Servomotors Irmotor=new Servomotors(); 
	private static double[] cord= new double[2];
	public static void main(String[] args) {
		Robot.setPort("/dev/tty.usbmodem14101");
		Robot.connect();
		//one of these two is run during tests
		
		Quadrent1_2();	
		Quadrent3_4();
		angleBetween();
		
		Robot.close();
		
}
	public static void location(int angle1, int angle2) {
		Navigation nav;
		int value;
		double[] soln = new double[2];
		nav = new Navigation();
		 nav.setAngles(angle1,angle2);
		 value = nav.newton_raphson();
		    if (value == Navigation.RETURN_SUCCESS) {
		// Retrieve solution of coordinates
		      soln = nav.getSolution();
		      System.out.println("(x,y) coordinates of robot = (" +
		                         soln[0] + "," + soln[1] + ")");
		    }
		    cord[0]= soln[0];
		    cord[1]= soln[1];
		    
	}
	
	public static void angleBetween() {
		beacon1=findBeacon1('G',180);
		beacon2=findBeacon2('N',beacon1.angle);
		int a1 = beacon1.angle;
		int a2 = beacon2.angle;
		int anglebetween= a1-a2;
		System.out.println("Angle Between: "+anglebetween);
	}
	
	public static beacon findBeacon1(char target,int a) {
		beacon B = new beacon(0,'0');
		Servomotors.rotate(11, a);
		if(IRReadOut.ScanIR()==0) {
			
			return findBeacon1(' ',a-5);
			
		}
		else {
			System.out.println("target aquired. tag: "+IRReadOut.tag+" Angle: "+a);
			B.charr=IRReadOut.Tag;
			B.angle=(180-a);
			return B;
		}
		
	}
	public static beacon findBeacon2(char target,int a) {
		beacon B = new beacon(0,'0');
		Servomotors.rotate(11, 180-a);
		if(IRReadOut.ScanIR(target)==0) {
			//System.out.println("not the target");
			return findBeacon2( target, a+5);
			
		}
		else {
			System.out.println("target aquired. tag: "+IRReadOut.tag+" Angle: "+a);
			B.charr=IRReadOut.Tag;
			B.angle=(180-a);
			return B;
		}
		
	}
	
	public static void Quadrent1_2() {
		Robot.setPort("/dev/tty.usbmodem14101");
		
		Servomotors.rotate(10, 180);
		RunMotors.distanceMove(1550,1);
		RunMotors.turnRightByAngle(150);
		RunMotors.distanceMove(1025,1);
		//lowers probe
		Servomotors.rotate(10, 10);
		Robot.sleep(5000);
		Conductivity.main();
		Robot.sleep(10000);
		//raises probe
		Servomotors.rotate(10, 180);
		Robot.sleep(5000);
		//back up for a tenth of a second
		Robot.close();
		Robot.connect();
		RunMotors.distanceMove(100,-1);
		//turn aproximitly 90ish degrees or you know the program just does the hell what ever the hell it wants.
		RunMotors.turnLeftByAngle(50);
		//move forward or not your choice program
		RunMotors.distanceMove(2400,1);
		
		Servomotors.rotate(10, 15);
		
		thermistors.main(10);
		Robot.sleep(5000);
		//raises probe
		Servomotors.rotate(10, 180);
		//fixes problem with actions overlapping
		Robot.close();
		Robot.connect();
		
		RunMotors.distanceMove(1000,-1);
		
		RunMotors.turnRightByAngle(89);
		
		RunMotors.distanceMove(1025,1);
		
		
		
		
		RunMotors.distanceMove(2000,1);
		Robot.close();
		//Sing im on top of the world. 
	}
	public static void Quadrent3_4() {
		Robot.setPort("/dev/tty.usbmodem14101");
		Robot.connect();
		RunMotors.distanceMove(1550,1);
		RunMotors.turnRightByAngle(115);
		RunMotors.distanceMove(1700,1);
		RunMotors.turnLeftByAngle(80);
		RunMotors.distanceMove(4500,1);

		
		
		
	}
	public static void quadrent1() { 
		location( findBeacon1(' ', 180).angle, findBeacon2(findBeacon1(' ', 180).charr, findBeacon1(' ', 180).angle).angle);
		//check orientation
		RunMotors.turnRightByAngle(int z);
		//RunMotors.distanceMove(lengthoframpin ft, 1);
		location( findBeacon1(' ', 180).angle, findBeacon2(findBeacon1(' ', 180).charr, findBeacon1(' ', 180).angle).angle);
		//RunMotors.distanceMove(distance between our x and hotspots x, 1);
		RunMotors.turnRightByAngle(90);
		//RunMotors.distanceMove(distance between our y and hotspots y, 1);
		//keep moving until bump trigered
		//deploy arm
		
		
	}
}


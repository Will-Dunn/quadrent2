
public class Location {

}

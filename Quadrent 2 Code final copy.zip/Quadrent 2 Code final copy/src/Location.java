
public class Location {
	beacon[] b= new beacon[3];
	public void main() {
		
	}
	public int getAngle() {
		
	}
	
}

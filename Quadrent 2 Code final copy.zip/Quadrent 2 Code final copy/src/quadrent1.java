
public class quadrent1 {
	public void main() {
		
	}
}
